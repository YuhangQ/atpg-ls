Scripts needed for the build process as well as some helper scripts.
