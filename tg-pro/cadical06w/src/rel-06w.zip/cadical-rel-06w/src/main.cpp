#include "app.hpp"

int main (int argc, char ** argv) {
  return CaDiCaL::App::main (argc, argv);
}
